<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>BurnerStory - Home</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="Cloud Kitchen" content="true">
    <link rel="icon" type="image/x-icon" href="images/favicon.png">
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Oswald:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
	
	<!-- BEGIN CSS STYLES -->
	<link rel="stylesheet" href="styles/bootstrap.css" type="text/css" media="all" />
	<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.css" type="text/css" media="all" />
	<link rel="stylesheet" href="fonts/font-awesome/css/line-awesome.css" type="text/css" media="all" />
	<link rel="stylesheet" href="styles/animate.css" type="text/css" media="all" />
	<link rel="stylesheet" href="styles/magnific-popup.css" type="text/css" media="all" />
	<link rel="stylesheet" href="styles/splitting.css" type="text/css" media="all" />
	<link rel="stylesheet" href="styles/swiper.css" type="text/css" media="all" />
	<link rel="stylesheet" href="style.css" type="text/css" media="all" />
	<!-- END CSS STYLES -->

</head>

<body>
	<div class="bg">

		<!-- Preloader -->
		<div class="preloader">
			<div class="centrize full-width">
				<div class="vertical-center">
					<div class="spinner-logo">
						<img src="images/burnerstory_logo.png" alt="" />
                        
						<div class="spinner-dot">
							<div class="spinner-line"></div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header -->
		<header class="kf-header">
		
			<!-- topline -->
			<div class="kf-topline">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
		
						<!-- hours -->
						<div class="kf-h-group">
							<i class="far fa-clock"></i>
							<em>opening hours :</em> 08:00 am - 09:00 pm
						</div>
		
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 align-center">
		
						<!-- social -->
						<div class="kf-h-social">
							<a href="facebook.com" target="blank"><i class="fab fa-facebook-f"></i></a>
							<a href="twitter.com" target="blank"><i class="fab fa-twitter"></i></a>
							<a href="instagram.com" target="blank"><i class="fab fa-instagram"></i></a>
							<a href="youtube.com" target="blank"><i class="fab fa-youtube"></i></a>
						</div>
		
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 align-right">
		
						<!-- location -->
						<div class="kf-h-group">
							<i class="fas fa-map-marker-alt"></i>
							<em>Location :</em> Dhanbad, Jharkhand, India
						</div>
		
					</div>
				</div>
			</div>
		
			<!-- navbar -->
			<div class="kf-navbar">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
		
						<!-- logo -->
						<div class="kf-logo">
							<a href="index.php"><img src="images/burnerstory_logo.png" alt="" /></a>
                    
						</div>
		
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 align-center">
		
						<!-- main menu -->
						<div class="kf-main-menu">
							<ul>
								
								<li><a href="#">Home</a></li>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Menu</a></li>
								<li><a href="#">Kitchen</a></li>
								
							</ul>
						</div>
		
					</div>
					<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 align-right">
		
						<!-- menu btn -->
						<a href="#" class="kf-menu-btn"><span></span></a>
		
						<!-- btn -->
						<a href="#" class="kf-btn h-btn">
							<span>Contact Us</span>
						</a>
		
					</div>
				</div>
			</div>
		
			<!-- mobile navbar -->
			<div class="kf-navbar-mobile">
		
				<!-- mobile menu -->
				<div class="kf-main-menu">
					<ul>
						
						<li><a href="#">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Menu</a></li>
                        <li><a href="#">Kitchen</a></li>
					</ul>
				</div>
		
				<!-- mobile topline -->
				<div class="kf-topline">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		
							<!-- mobile btn -->
							<a href="#" class="kf-btn h-btn">
								<span>Contact Us</span>
								<i class="fas fa-chevron-right"></i>
							</a>
		
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		
							<!-- social -->
							<div class="kf-h-social">
								<a href="facebook.com" target="blank"><i class="fab fa-facebook-f"></i></a>
								<a href="twitter.com" target="blank"><i class="fab fa-twitter"></i></a>
								<a href="instagram.com" target="blank"><i class="fab fa-instagram"></i></a>
								<a href="youtube.com" target="blank"><i class="fab fa-youtube"></i></a>
							</div>
		
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		
							<!-- hours -->
							<div class="kf-h-group">
								<i class="far fa-clock"></i>
								<em>opening hours :</em> 08:00 am - 09:00 pm
							</div>
		
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		
							<!-- location -->
							<div class="kf-h-group">
								<i class="fas fa-map-marker-alt"></i>
								<em>Location :</em> Dhanbad, Jharkhand, India
							</div>
		
						</div>
					</div>
				</div>
		
			</div>
		
		</header>

		<!-- Wrapper -->
		<div class="wrapper">

			<!-- Section Started Slider -->
			<section class="section kf-started-slider">
				<div class="swiper-container">
					<div class="swiper-wrapper">
						<div class="swiper-slide">

							<div class="kf-started-item">
								<div class="slide js-parallax" style="background-image: url(images/started_img_n6.jpg);"></div>
								<div class="container">
									<div class="description align-left element-anim-1">
										<div class="subtitles">
											Welcome to the Burnerstory
										</div>
										<h2 class="name text-anim-1" data-splitting="chars">
											Sizzling Flavors, Delivered <br>Fresh to Your Doorstep!
										</h2>
										<div class="kf-bts">
											<a href="#" class="kf-btn">
												<span>explore more</span>
												<i class="fas fa-chevron-right"></i>
											</a>
											<a href="#" class="kf-btn dark-btn">
												<span>get delivery</span>
												<i class="fas fa-chevron-right"></i>
											</a>
										</div>
									</div>
								</div>
							</div>

						</div>
						<div class="swiper-slide">

							<div class="kf-started-item">
								<div class="slide js-parallax" style="background-image: url(images/started_img_n5.jpg);"></div>
								<div class="container">
									<div class="description align-left element-anim-1">
										<div class="subtitles">
											Welcome to the Burnerstory
										</div>
										<h2 class="name text-anim-1" data-splitting="chars">
											Craving Satisfaction, <br>One Order at a Time!
										</h2>
										<div class="kf-bts">
											<a href="#" class="kf-btn">
												<span>explore more</span>
												<i class="fas fa-chevron-right"></i>
											</a>
											<a href="#" class="kf-btn dark-btn">
												<span>get delivery</span>
												<i class="fas fa-chevron-right"></i>
											</a>
										</div>
									</div>
								</div>
							</div>

						</div>
						
					</div>

					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>

				</div>
			</section>

			<!-- Section About -->
			<section class="section kf-about section-bg">
				<div class="container">

					<div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">

							<div class="kf-titles">
								<div class="kf-subtitle element-anim-1 scroll-animate" data-animate="active">
									About Us
								</div>
								<h3 class="kf-title element-anim-1 scroll-animate" data-animate="active">
									Crafting Flavors, <br>Delivering Excellence
								</h3>
							</div>

							<div class="kf-text element-anim-1 scroll-animate" data-animate="active">
								<p style="text-align:justify;">
									At BurnerStory, we’re more than just a cloud kitchen; we’re a culinary experience brought straight to your home. Our mission is to craft unforgettable meals, blending authentic flavors with modern convenience. We take pride in sourcing the finest ingredients, creating dishes that not only satisfy your cravings but also tell a story with every bite. Whether you’re indulging in a quick meal or a gourmet feast, BurnerStory is here to elevate your dining experience.

With a passion for innovation and a commitment to quality, we strive to deliver excellence, from our kitchen to your doorstep. Discover the taste of something special with BurnerStory — where every order is a chapter in our flavorful journey.
								</p>
							</div>

							

						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-7">

							<div class="kf-about-image element-anim-1 scroll-animate" data-animate="active">
								<img src="images/about_img.png" alt="" />
							</div>

						</div>
					</div>

				</div>
			</section>

			<!-- Section Services -->
			<section class="section kf-services section-bg">
				<div class="container">

					<div class="kf-services-items row">

						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<div class="kf-services-item element-anim-1 scroll-animate" data-animate="active">
								<div class="image kf-image-hover">
									<a href="#"><img src="images/service1.jpg" alt="" /></a>
								</div>
								<div class="desc">
									<div class="icon"><i class="las la-utensils"></i></div>
									<h5 class="name">Restaurant Menu</h5>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<div class="kf-services-item element-anim-1 scroll-animate" data-animate="active">
								<div class="image kf-image-hover">
									<a href="#"><img src="images/service2.jpg" alt="" /></a>
								</div>
								<div class="desc">
									<div class="icon"><i class="las la-coffee"></i></div>
									<h5 class="name">Food Menu</h5>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<div class="kf-services-item element-anim-1 scroll-animate" data-animate="active">
								<div class="image kf-image-hover">
									<a href="#"><img src="images/service3.jpg" alt="" /></a>
								</div>
								<div class="desc">
									<div class="icon"><i class="las la-glass-cheers"></i></div>
									<h5 class="name">Food Services</h5>
								</div>
							</div>
						</div>

					</div>

				</div>
			</section>

			<!-- Section Menu -->
			<section class="section kf-menu kf-parallax" style="background-image: url(images/services-1.png);">
				<div class="container">

					<div class="kf-titles align-center">
						<div class="kf-subtitle element-anim-1 scroll-animate" data-animate="active">
							Choose Best Food
						</div>
						<h3 class="kf-title element-anim-1 scroll-animate" data-animate="active">
							Burnerstory Popular Food Menu
						</h3>
					</div>

					<div class="kf-menu-items">
						<div class="row">

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<div class="kf-menu-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/menu1.jpg" class="has-popup-image"><img src="images/menu1.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Americano Food</h5>
										<div class="subname">2/3 espresso, 1/3 streamed milk</div>
<!--										<div class="price">$4.9</div>-->
									</div>
								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<div class="kf-menu-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/menu2.jpg" class="has-popup-image"><img src="images/menu2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Espresso Food</h5>
										<div class="subname">2/3 espresso, 1/3 streamed milk</div>
<!--										<div class="price">$4.9</div>-->
									</div>
								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<div class="kf-menu-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/menu3.jpg" class="has-popup-image"><img src="images/menu3.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Barista Pouring Syrup</h5>
										<div class="subname">2/3 espresso, 1/3 streamed milk</div>
<!--										<div class="price">$3.5</div>-->
									</div>
								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<div class="kf-menu-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/menu4.jpg" class="has-popup-image"><img src="images/menu4.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Cold - Food</h5>
										<div class="subname">2/3 espresso, 1/3 streamed milk</div>
<!--										<div class="price">$6.0</div>-->
									</div>
								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<div class="kf-menu-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/menu5.jpg" class="has-popup-image"><img src="images/menu5.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Cappuccino Arabica</h5>
										<div class="subname">2/3 espresso, 1/3 streamed milk</div>
<!--										<div class="price">$2.8</div>-->
									</div>
								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
								<div class="kf-menu-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/menu6.jpg" class="has-popup-image"><img src="images/menu6.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Milk Cream Food</h5>
										<div class="subname">2/3 espresso, 1/3 streamed milk</div>
<!--										<div class="price">$7.5</div>-->
									</div>
								</div>
							</div>

						</div>
					</div>

				</div>
			</section>

			<!-- Section Choose -->
			<section class="section kf-choose section-bg">
				<div class="container">
					<div class="kf-parallax-icon pi-1" data-jarallax-element="-60">
						<div class="p-icon" style="background-image: url(images/parallax_icon1.png);"></div>
					</div>
					<div class="kf-parallax-icon pi-2" data-jarallax-element="-80">
						<div class="p-icon" style="background-image: url(images/parallax_icon2.png);"></div>
					</div>
					<div class="kf-parallax-icon pi-3" data-jarallax-element="-40">
						<div class="p-icon" style="background-image: url(images/parallax_icon3.png);"></div>
					</div>

					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">

							<div class="kf-choose-image element-anim-1 scroll-animate" data-animate="active">
								<img src="images/choose_img.jpg" alt="" />
							</div>

						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-5 offset-lg-1 align-self-center">

							<div class="kf-titles">
								<div class="kf-subtitle element-anim-1 scroll-animate" data-animate="active">
									Why Choose Us
								</div>
								<h3 class="kf-title element-anim-1 scroll-animate" data-animate="active">
									Fresh, Fast, Flavorful, <br>Every Time
								</h3>
							</div>

							<div class="kf-text element-anim-1 scroll-animate" data-animate="active">
								<p>
									At BurnerStory, we prioritize quality, convenience, and taste. Our expertly crafted dishes use only the freshest ingredients, ensuring every meal is a delight. With fast, reliable delivery and a menu catering to all tastes, we make dining easy, delicious, and hassle-free—every single time.
								</p>
							</div>

							<div class="kf-choose-list">
								<ul>
									<li class="element-anim-1 scroll-animate" data-animate="active">
										<div class="icon">
											<img src="images/choose_icon1.png" alt="" />
										</div>
										<div class="desc">
											<h5 class="name">Premium Ingredients</h5>
											<div class="subname">We use fresh, high-quality ingredients to ensure every meal is flavorful and satisfying.</div>
										</div>
									</li>
									<li class="element-anim-1 scroll-animate" data-animate="active">
										<div class="icon">
											<img src="images/choose_icon2.png" alt="" />
										</div>
										<div class="desc">
											<h5 class="name">Reliable Delivery</h5>
											<div class="subname">Enjoy fast, convenient delivery straight to your door, making great food accessible anytime.</div>
										</div>
									</li>
								</ul>
							</div>

							<a href="#" class="kf-btn element-anim-1 scroll-animate" data-animate="active">
								<span>explore more</span>
								<i class="fas fa-chevron-right"></i>
							</a>

						</div>
					</div>

				</div>
			</section>

			<!-- Section Grid Carousel -->
			<section class="section kf-grid-carousel">
				<div class="container">
					<div class="swiper-container">
						<div class="swiper-wrapper">
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
							<div class="swiper-slide">

								<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
									<div class="image kf-image-hover">
										<a href="images/grid_gal2.jpg" class="has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
									</div>
									<div class="desc">
										<h5 class="name">Food</h5>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</section>

			<!-- Section Testimonials Carousel -->
			<section class="section kf-testimonials kf-testimonials-2 section-bg" style="background-image: url(images/services-1.png);">
				<div class="container">

					<div class="kf-titles align-center">
						<div class="kf-subtitle element-anim-1 scroll-animate" data-animate="active">
							Customer Feedback
						</div>
						<h3 class="kf-title element-anim-1 scroll-animate" data-animate="active">
							What Our Clients Say
						</h3>
					</div>

					<div class="kf-testimonials-carousel">
						<div class="swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide">

									<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
										<div class="image">
											<img src="images/rev1.jpg" alt="" />
										</div>
										<div class="desc">
											<div class="stars">
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
											</div>
											<div class="text">
												Sed ut perspiciatis unde omnis natus error luptatem accusantium doloremque laudantium
												totam remriam eaque quae abillo
											</div>
											<h5 class="name">Frederick S. France <em>Web Deigner</em></h5>
										</div>
									</div>

								</div>
								<div class="swiper-slide">

									<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
										<div class="image">
											<img src="images/rev2.jpg" alt="" />
										</div>
										<div class="desc">
											<div class="stars">
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
											</div>
											<div class="text">
												Sed ut perspiciatis unde omnis natus error luptatem accusantium doloremque laudantium
												totam remriam eaque quae abillo
											</div>
											<h5 class="name">James M. London <em>Lawyer</em></h5>
										</div>
									</div>

								</div>
								<div class="swiper-slide">

									<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
										<div class="image">
											<img src="images/rev3.jpg" alt="" />
										</div>
										<div class="desc">
											<div class="stars">
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
											</div>
											<div class="kf-text">
												Sed ut perspiciatis unde omnis natus error luptatem accusantium doloremque laudantium
												totam remriam eaque quae abillo
											</div>
											<h5 class="name">Olivia D. New York <em>Dentist</em></h5>
										</div>
									</div>

								</div>
								<div class="swiper-slide">

									<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
										<div class="image">
											<img src="images/rev1.jpg" alt="" />
										</div>
										<div class="desc">
											<div class="stars">
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
											</div>
											<div class="kf-text">
												Sed ut perspiciatis unde omnis natus error luptatem accusantium doloremque laudantium
												totam remriam eaque quae abillo
											</div>
											<h5 class="name">Frederick S. France <em>Web Deigner</em></h5>
										</div>
									</div>

								</div>
								<div class="swiper-slide">

									<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
										<div class="image">
											<img src="images/rev2.jpg" alt="" />
										</div>
										<div class="desc">
											<div class="stars">
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
											</div>
											<div class="kf-text">
												Sed ut perspiciatis unde omnis natus error luptatem accusantium doloremque laudantium
												totam remriam eaque quae abillo
											</div>
											<h5 class="name">James M. London <em>Lawyer</em></h5>
										</div>
									</div>

								</div>
								<div class="swiper-slide">

									<div class="slide-item element-anim-1 scroll-animate" data-animate="active">
										<div class="image">
											<img src="images/rev3.jpg" alt="" />
										</div>
										<div class="desc">
											<div class="stars">
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
											</div>
											<div class="kf-text">
												Sed ut perspiciatis unde omnis natus error luptatem accusantium doloremque laudantium
												totam remriam eaque quae abillo
											</div>
											<h5 class="name">Olivia D. New York <em>Dentist</em></h5>
										</div>
									</div>

								</div>
							</div>

							<div class="swiper-pagination"></div>

						</div>
					</div>

				</div>
			</section>

			<!-- Section Numbers -->
			<section class="section kf-numbers">
				<div class="container">

					<div class="kf-numbers-items row">

						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
							<div class="kf-numbers-item">
								<div class="num">256+</div>
								<div class="desc">
									<h5 class="name">Premium Clients</h5>
									<div class="subname">Sed ut perspiciatis unde</div>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
							<div class="kf-numbers-item">
								<div class="num">362+</div>
								<div class="desc">
									<h5 class="name">Expert Members</h5>
									<div class="subname">Sed ut perspiciatis unde</div>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
							<div class="kf-numbers-item">
								<div class="num">753+</div>
								<div class="desc">
									<h5 class="name">Winning Awards</h5>
									<div class="subname">Sed ut perspiciatis unde</div>
								</div>
							</div>
						</div>

					</div>

				</div>
			</section>

			<!-- Section Latest Blog -->
			<section class="section kf-latest-blog section-bg" style="display:none;">
				<div class="container">

					<div class="kf-titles align-center">
						<div class="kf-subtitle element-anim-1 scroll-animate" data-animate="active">
							Get Every Single Update
						</div>
						<h3 class="kf-title element-anim-1 scroll-animate" data-animate="active">
							Read Some Latest Blog & News
						</h3>
					</div>

					<div class="kf-blog-grid-items row">

						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<div class="kf-blog-grid-item element-anim-1 scroll-animate" data-animate="active">
								<div class="image kf-image-hover">
									<a href="#"><img src="images/latest_blog1.jpg" alt="" /></a>
								</div>
								<div class="desc">
									<h5 class="name">SWR React Hooks With Next Increm Ental Static Regeneration</h5>
									<div class="kf-date"><i class="far fa-calendar-alt"></i>25 Sep 2021</div>
									<div class="kf-comm"><i class="far fa-comments"></i>Comments (7)</div>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<div class="kf-blog-grid-item element-anim-1 scroll-animate" data-animate="active">
								<div class="image kf-image-hover">
									<a href="#"><img src="images/latest_blog2.jpg" alt="" /></a>
								</div>
								<div class="desc">
									<h5 class="name">Decisions For Building Flexible Components DevTools Browser</h5>
									<div class="kf-date"><i class="far fa-calendar-alt"></i>25 Sep 2021</div>
									<div class="kf-comm"><i class="far fa-comments"></i>Comments (7)</div>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
							<div class="kf-blog-grid-item element-anim-1 scroll-animate" data-animate="active">
								<div class="image kf-image-hover">
									<a href="#"><img src="images/latest_blog3.jpg" alt="" /></a>
								</div>
								<div class="desc">
									<h5 class="name">SWR React Hooks With Next Increm Ental Static Regeneration</h5>
									<div class="kf-date"><i class="far fa-calendar-alt"></i>25 Sep 2021</div>
									<div class="kf-comm"><i class="far fa-comments"></i>Comments (7)</div>
								</div>
							</div>
						</div>

					</div>

					<div class="align-center">

						<a href="#" class="kf-btn element-anim-1 scroll-animate" data-animate="active">
							<span>view all</span>
							<i class="fas fa-chevron-right"></i>
						</a>

					</div>

				</div>
			</section>

			<!-- Section CTA -->
			<!--<section class="section kf-cta kf-parallax" style="background-image: url(images/cta_bg.jpg);">
				<div class="container">

					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">

							<div class="kf-titles">
								<div class="kf-subtitle element-anim-1 scroll-animate" data-animate="active">
									Need a Table On Food House
								</div>
								<h3 class="kf-title element-anim-1 scroll-animate" data-animate="active">
									Booking Table For Your & Family Members
								</h3>
							</div>

						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4 align-self-center align-right">

							<a href="#" class="kf-btn element-anim-1 scroll-animate" data-animate="active">
								<span>booking table</span>
								<i class="fas fa-chevron-right"></i>
							</a>

						</div>
					</div>

				</div>
			</section>-->

		</div>

		<!-- Footer -->
	  <div class="kf-footer">
	  	<div class="container">
	  		<div class="row">
	  			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
	  
	  				<!-- logo -->
	  				<div class="kf-logo element-anim-1 scroll-animate" data-animate="active">
	  					<a href="index.php"><img src="images/burnerstory_logo.png" alt="" /></a>
	  			
	  				</div>
	  
	  			</div>
	  			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
	  
	  				<!-- hours -->
	  				<div class="kf-f-hours element-anim-1 scroll-animate" data-animate="active">
	  					<h5>Working Hours</h5>
	  					<ul>
	  						<li>
	  							Sunday - Thursday
	  							<em>08:00 am - 09:00pm</em>
	  						</li>
	  						<li>
	  							Only Friday
	  							<em>03:00 pm - 09:00pm</em>
	  						</li>
	  						<li>
	  							<strong>Saturday Close</strong>
	  						</li>
	  					</ul>
	  				</div>
	  
	  			</div>
	  			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
	  
	  				<!-- contact -->
	  				<div class="kf-f-contact element-anim-1 scroll-animate" data-animate="active">
	  					<h5>Contact Us</h5>
	  					<ul>
	  						<li>
	  							<i class="las la-map-marker"></i>
	  							<em>Location :</em>
	  							Dhanbad, Jharkhand, India
	  						</li>
	  						<li>
	  							<i class="las la-envelope-open-text"></i>
	  							<em>Email Address :</em>
	  							hello@burnerstory.com
	  						</li>
	  						<li>
	  							<i class="las la-phone"></i>
	  							<em>Phone Number :</em>
	  							(+91) - 9953532397
	  						</li>
	  					</ul>
	  				</div>
	  
	  			</div>
	  			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
	  
	  				<!-- gallery -->
	  				<div class="kf-f-gallery element-anim-1 scroll-animate" data-animate="active">
	  					<h5>Gallery</h5>
	  					<ul>
	  						<li>
	  							<a href="images/grid_gal1.jpg" class="kf-image-hover has-popup-image"><img src="images/grid_gal1.jpg" alt="" /></a>
	  						</li>
	  						<li>
	  							<a href="images/grid_gal2.jpg" class="kf-image-hover has-popup-image"><img src="images/grid_gal2.jpg" alt="" /></a>
	  						</li>
	  						<li>
	  							<a href="images/grid_gal3.jpg" class="kf-image-hover has-popup-image"><img src="images/grid_gal3.jpg" alt="" /></a>
	  						</li>
	  						<li>
	  							<a href="images/grid_gal4.jpg" class="kf-image-hover has-popup-image"><img src="images/grid_gal4.jpg" alt="" /></a>
	  						</li>
	  						<li>
	  							<a href="images/grid_gal5.jpg" class="kf-image-hover has-popup-image"><img src="images/grid_gal5.jpg" alt="" /></a>
	  						</li>
	  						<li>
	  							<a href="images/grid_gal6.jpg" class="kf-image-hover has-popup-image"><img src="images/grid_gal1.jpg" alt="" /></a>
	  						</li>
	  					</ul>
	  				</div>
	  
	  			</div>
	  		</div>
	  		<div class="row">
	  			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 align-center">
	  
	  				<!-- copyright -->
	  				<div class="kf-copyright element-anim-1 scroll-animate" data-animate="active">
	  					Copyright © 2024 BurnerStory. All Rights Reserved.
	  				</div>
	  
	  			</div>
	  		</div>
	  	</div>
	  </div>

	</div>

	<!-- Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/swiper.js"></script>
	<script src="js/splitting.js"></script>
	<script src="js/jquery.paroller.min.js"></script>
	<script src="js/parallax.js"></script>
	<script src="js/magnific-popup.js"></script>
	<script src="js/imagesloaded.pkgd.js"></script>
	<script src="js/isotope.pkgd.js"></script>
	<script src="js/jquery.scrolla.js"></script>
	<script src="js/skrollr.js"></script>
	<script src="js/common.js"></script>
</body>
</html>